﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MgwenyaKMM_Assign2.Models
{
    public interface IGuestResponseRepository
    {
        IEnumerable<GuestResponse> GetAllGuestResponses();
        GuestResponse GetGuestResponseByEmail(string @email);
        GuestResponse GetGuestResponseByCellularNumber(string phone_number);
        void AddResponse(GuestResponse guestResponse);


    }
}
