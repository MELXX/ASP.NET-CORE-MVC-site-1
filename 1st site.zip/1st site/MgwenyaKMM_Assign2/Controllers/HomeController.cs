﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MgwenyaKMM_Assign2.Models;
using Microsoft.AspNetCore.Mvc;

namespace MgwenyaKMM_Assign2.Controllers
{
   
    public class HomeController : Controller
    {
        private  IGuestResponseRepository guestResponse;

        public HomeController(IGuestResponseRepository _guestResponse)
        {
            guestResponse = _guestResponse;
        }
       public ViewResult Index()
        {
            return View();
        }

        public IActionResult thisView()
        {
            return View();
        }


        [HttpGet]
        public ViewResult RsvpForm()
        {
            return View();
        }
        [HttpPost]
        public ViewResult RsvpForm(GuestResponse guestResponse)
        {
            // To do: E-mail guestResponse to the party organizer
            return View("Thanks", guestResponse);
        }
    }
}